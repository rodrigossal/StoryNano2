//
//  InitialText.swift
//  Story
//
//  Created by Rodrigo Salles Stefani on 05/02/18.
//  Copyright © 2018 Rodrigo Salles Stefani. All rights reserved.
//

import UIKit

class InitialText{
    
    var text = [String]()
    
    init() {
        text.append("A Beautiful story of 2 friends that aren't friends")
        text.append("One Beautiful day one of the friends bullied another friend")
        text.append("The Bully was MAD, the bullied was SAD, Beautiful new names")
        text.append("On that Beautiful evening they changed their facebook status")
        text.append("Created Beautiful tweets, cursing one another")
        text.append("They are training to have a Beautiful fight")
        text.append("BEAUTIFUL")
        text.append("beautiful")
    }
}
