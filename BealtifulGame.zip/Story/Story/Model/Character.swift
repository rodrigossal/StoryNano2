//
//  BlueStats.swift
//  Story
//
//  Created by Rodrigo Salles Stefani on 02/02/18.
//  Copyright © 2018 Rodrigo Salles Stefani. All rights reserved.
//

import Foundation


class Character {
    
    var damage : Int
    
    init() {
        damage = 0
    }
    
    func train(){
        self.damage += 1
    }
    
    
}
