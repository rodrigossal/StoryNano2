//
//  Characters.swift
//  Story
//
//  Created by Rodrigo Salles Stefani on 02/02/18.
//  Copyright © 2018 Rodrigo Salles Stefani. All rights reserved.
//

import Foundation


class CharacterStore {
    
    static var main = CharacterStore()
    
    
    var sad = Character()
    var mad = Character()
    
    private init(){}
    
}
